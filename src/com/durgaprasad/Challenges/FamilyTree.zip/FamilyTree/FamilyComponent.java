package com.durgaprasad.FamilyTree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public abstract class FamilyComponent {
    public void add(FamilyComponent f){
        throw new UnsupportedOperationException();
    }

    public String getName(){
        throw new UnsupportedOperationException();
    }

    public String getGender(){
        throw new UnsupportedOperationException();
    }

    public boolean searchChildren(String name){
        throw new UnsupportedOperationException();
    }

    public ArrayList<FamilyComponent> getSons(String name){
        throw new UnsupportedOperationException();
    }

    public ArrayList<FamilyComponent> getDaughters(String name){
        throw new UnsupportedOperationException();
    }

    public ArrayList<FamilyComponent> getChildren(){
        throw new UnsupportedOperationException();
    }


}
